<?php
$con=mysqli_connect("localhost","root","","a");
// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_errno();
  }
session_start();
//$_SESSION['myValue']=;
$userid=$_POST['userid'];
$pass=$_POST['password'];
//$sql="SELECT * FROM entry where userid='$userid' AND password='$pass'";
$bla=mysqli_query($con,"SELECT * FROM entry where userid='$userid' AND password='$pass'") or exit('$sql failed:'.mysqli_errno());
$blabla=mysqli_fetch_array($bla);
$_SESSION['myValue']=$blabla['name'];
//echo "name:".$blabla['name'];
if($userid==$blabla['userid'])
{
	header('Location:web.php'); 
//echo "name:".$blabla['name'];
//$_SESSION['myValue']=$blabla['name'];
}
else
{
	echo "<script>alert('user name or password is incorrect..TRY AGAIN'); window.location = 'front.html';</script>";

}
?>