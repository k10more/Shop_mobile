<?php
$link=mysqli_connect('localhost','root','','samsung');
if(mysqli_connect_errno($link))
{
	echo "failed";
}
$v=mysqli_query($link,"SELECT bal FROM te WHERE name='sam1'");
$row=mysqli_fetch_array($v);
if($row['bal']==0 || $row['bal']<=0)
{   
    echo"<h1 style='color:red;'>SORRY...THE PRODUCT U ARE LOOKING IS CUURENTLY NOT AVAILABLE...!</h1>";
	echo '<a href="de4.html">Click here to buy another product!</a>';
}
 else {
     header("Location:lastpage.html");
	}
$h=mysqli_query($link,"SELECT bal FROM te WHERE name='sam1'");
$ro=mysqli_fetch_array($h);
$k=$ro['bal']-1;
$sql=mysqli_query($link, "UPDATE  te SET bal='$k' WHERE name='sam1'");

?>