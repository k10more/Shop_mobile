<?php
$link=mysqli_connect('localhost','root','','b');
if(mysqli_connect_errno($link))
{
	echo "failed";
}
$v=mysqli_query($link,"SELECT bal FROM te");
$row=mysqli_fetch_array($v);
if($row['bal']==0 || $row['bal']<=0)
{ //header('Location:error.php');
   echo"not avl";
}
 else {
    //header("Location:welcome.php");
     echo "avl";
	}
//$k=$row['bal']-1;
//$sql=mysqli_query($link, "UPDATE  te SET bal='$k' WHERE name='moto1'");
$h=mysqli_query($link,"SELECT bal FROM te");
$ro=mysqli_fetch_array($h);
$k=$ro['bal']-1;
$sql=mysqli_query($link, "UPDATE  te SET bal='$k' WHERE name='moto1'");
/*if($ro['bal']==0 || $ro['bal']<=0)
{ //header('Location:error.php');
   echo"not avl";
}
 else {
    //header("Location:welcome.php");
     echo "avl";
	}*/
?>