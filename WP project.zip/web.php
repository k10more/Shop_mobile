<!DOCTYPE html>
<html>
<style>
body{
	background-image:url("background12.jpg");
	background-size:100% 100%;
}
</style>
<body>
<h1><b><center>Mobi-shop</b></center></h1>
   <hr>
<?php
session_start();
echo '<h1 style="color:blue;"><marquee>WELCOME ',$_SESSION['myValue'],',',' SELECT YOUR CATEGORY</marquee>';
?>
<br>
<center><a href="de.html"><img src="Images/iPhone-logo1.png" alt="Iphone" style="width:512px;height:128px;"></a></center><br>
<center><a href="de3.html"><img src=Images/Motorola.png alt=Moto style="width:512px;height:128px;"></a></center><br>
<center><a href="de4.html"><img src=Images/samsung.png alt=Samsung style="width:512px;height:128px;"></a></center><br>
<center><a href="de2.html"><img src=Images/windows.png alt=Windows style="width:512px;height:128px;"></a></center><br>
<center><a href="de5.html"><img src=Images/micromax.jpg alt=Micromax style="width:512px;height:128px;"></a></center>
</body>
</html>