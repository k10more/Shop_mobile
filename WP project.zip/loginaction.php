<?php
$link=mysqli_connect('localhost','root','','a');
if(mysqli_connect_errno($link))
{
	echo "failed";
}
$name=$_POST['name'];
$userid=$_POST['userid'];
$Email=$_POST['email'];
$Moblie_no=$_POST['usrtel'];
$password=$_POST['psw'];
$birthday=$_POST['bday'];
//$age=$_POST['num'];
$address=$_POST['message'];
$checka=mysqli_query($link,"SELECT * FROM entry where userid='$userid'") or exit('$sql failed:'.mysqli_errno());
$ck=mysqli_fetch_array($checka);
if($userid==$ck['userid'])
{
	echo "<script>alert('user name already exist..try with different name'); window.location = 'form.html';</script>";
} else {
mysqli_query($link,"INSERT INTO entry VALUES('$name','$userid','$Email','$Moblie_no','$password','$birthday','$address')");
if(mysqli_affected_rows($link)>0)
{
	echo"<h1 style='color:green;'>succesfully created account..</h1>";
	echo '<a href="front.html">LOGIN</a>';
}
else
 {
	echo "not succesful".mysqli_error($link);
 }
}
?>